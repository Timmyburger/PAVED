#!/usr/bin/env python

import rospy
from std_msgs.msg import Float32, Time

def publisher():
  #rospy.Publisher(topic,type,queue_size)
  pub_time = rospy.Publisher('time', Time, queue_size=10)
  pub_wheel_speed = rospy.Publisher('topic_wheel_speed', Float32, queue_size=1)
  pub_steer_angle = rospy.Publisher('topic_steer_angle', Float32, queue_size=1)
  rate = rospy.Rate(10)
  wheel_speed = Float32()
  steer_angle = Float32()
  counter = 0
  countdown = 99999

  while not rospy.is_shutdown():
    #**********************#
    #Replace the following with sensor data calls:
    #Setup
    time = rospy.get_rostime()
    #echo_wheel_speed = "wheel_speed: %.1f" %counter
    #echo_steer_angle = "steer_angle: %.1f" %countdown
    #echo_time = "time: %s" %time
    counter += 1
    countdown -= 1
    #Send data to publishing Object
    #wheel_speed.data = echo_wheel_speed
    #steer_angle.data = echo_steer_angle

    #***********************#
    #Replace the following with sensor data objects:
    #Publish message
    pub_time.publish(time)
    pub_wheel_speed.publish(float(counter))
    pub_steer_angle.publish(float(countdown))

    #Log incoming data and print to screen
    #rospy.loginfo(time)
    #rospy.loginfo(echo_wheel_speed)
    #rospy.loginfo(echo_steer_angle)
    #Pause loop for duration of Rate()
    rate.sleep()

if __name__ == "__main__":
    rospy.init_node("node_DAQ")
    publisher()
