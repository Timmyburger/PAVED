#!/usr/bin/env python

#Streams in data from LabJack and publishes to the appropriate topics

import u6
import sys
import rospy
from std_msgs.msg import Float32, Time

def publisher():
    pub_time = rospy.Publisher('time', Time, queue_size=10)
    pub_wheel_speed = rospy.Publisher('topic_wheel_speed', Float32, queue_size=1)
    pub_steer_angle = rospy.Publisher('topic_steer_angle', Float32, queue_size=1)

    wheel_speed = Float32()
    steer_angle = Float32()

    time = rospy.get_rostime()

    pub_time.publish(time)

    for i in d.streamData():
        SA_Read = sum(i["AIN0"])/len(i["AIN0"])
        pub_steer_angle.publish(float(SA_Read))

if __name__ == "__main__":
    #Configure LabJack H/W
    d = u6.U6()
    d.getCalibrationData()
    #Configure LabJack stream variables
    #See labjack.com/support/datasheets/u6/low-level-function-reference/streamconfig
    #for definitions of streamConfig variables

    #Publishing rate corresponds to ScanFreq/5
    ScanFreq = 10000 #Hz
    SampleNum = 10
    d.streamConfig(NumChannels=2, ChannelNumbers=[0, 1], ChannelOptions=[0, 0],\
        SettlingFactor=1, ResolutionIndex=0, ScanFrequency=ScanFreq,\
        SamplesPerPacket=SampleNum)

    #Initialize node
    rospy.init_node("node_DAQ")
    #Start stream
    d.streamStart()

    #Run publisher
    while not rospy.is_shutdown():
        publisher()

    d.streamStop()
    d.close()
