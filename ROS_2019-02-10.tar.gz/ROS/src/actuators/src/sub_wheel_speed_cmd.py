#!/usr/bin/env python

import rospy
from std_msgs.msg import Float32

def subscriber():
    sub = rospy.Subscriber('topic_wheel_speed_cmd', Float32, callback)
    rospy.spin()

def callback(message):
    rospy.loginfo("Wheel Speed Command: %s" %message.data)

if __name__ == '__main__':
    rospy.init_node("node_wheel_speed_cmd_listener")
    subscriber()
