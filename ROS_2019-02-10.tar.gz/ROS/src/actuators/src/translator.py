#!/usr/bin/env python

import rospy
import serial
import time
import struct
from std_msgs.msg import Float32
from numpy import interp

#Set global varialbe to pass to subscriber

SA_cmd = ''
WS_cmd = ''
#last_SA_cmd = 0

#Serial communication over USB. To find the current arduino port, type
#"ls -l /dev/ttyACM*" into the terminal
port = '/dev/ttyACM0'
#Establish connection on port at specified baud rate
arduino = serial.Serial(port,115200,timeout=0)

def callback1(msg):
    global SA_cmd
    # Takes value and remaps to percentage of servo range 0% to 100%
    SA_temp = interp(msg.data,[0,5.1],[0,1])
    BlinkSpeed = 250 #ms
    SA_cmd = str('<LED1,%i,%.2f>' %(BlinkSpeed, SA_temp))

def callback2(msg):
    global WS_cmd
    WS_cmd = str('%.3f' %msg.data)

def subscriber():
    sub_SA = rospy.Subscriber('topic_steer_angle_cmd', Float32, callback1)
    sub_WS = rospy.Subscriber('topic_wheel_speed_cmd', Float32, callback2)
    #data = <sub_SA, sub_WS>
    #ser.write(data.encode())
    #buffer = '<sub_SA,sub_WS>'

if __name__ == '__main__':
    rospy.init_node("node_translator")
    rate = rospy.Rate(4) #Hz
    # SA_cmd_temp = SA_cmd
    delay = 4
    currenttime = time.time()

    while not rospy.is_shutdown():
        subscriber()
        arduino.write(SA_cmd)
        print(SA_cmd)
        rate.sleep()
        # if (time.time() - currenttime) > delay:
        #     time.sleep(1)
        #     arduino.flushOutput
        #     currenttime = time.time()
    print('Closing comm port')
    arduino.close()
