#!/usr/bin/env python

import rospy
from std_msgs.msg import Float32

def subscriber():
    sub = rospy.Subscriber('topic_steer_angle_cmd', Float32, callback)
    rospy.spin()

def callback(message):
    rospy.loginfo("Steering Angle Command: %s" %message.data)

if __name__ == '__main__':
    rospy.init_node("node_steer_angle_cmd_listener")
    subscriber()
