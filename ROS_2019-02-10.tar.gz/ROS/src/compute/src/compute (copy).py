#!/usr/bin/env python

import rospy
from std_msgs.msg import Float32

var = None

def subscriber():
    sub = rospy.Subscriber('topic_wheel_speed', Float32, callback)

def publisher(data):
    pub_wheel_speed_cmd = rospy.Publisher('topic_wheel_speed_cmd', Float32, queue_size=10)
    pub_wheel_speed_cmd.publish(data)
    rospy.loginfo(data)

def callback(message):
    global var
    var == message.data
    rospy.loginfo("Wheel Speed: %s" %message.data)

if __name__ == '__main__':
    rospy.init_node("node_wheel_speed_cmd")
    subscriber()
    publisher(var)
    rate = rospy.Rate(1)
    rate.sleep()
