#!/usr/bin/env python

import rospy
import os
from std_msgs.msg import Float32

def subscriber():
    sub1 = rospy.Subscriber('topic_steer_angle', Float32, callback_SA)
    sub2 = rospy.Subscriber('topic_steer_angle_cmd', Float32, callback_SA_cmd)
    sub3 = rospy.Subscriber('topic_wheel_speed', Float32, callback_WS)
    sub4 = rospy.Subscriber('topic_wheel_speed_cmd', Float32, callback_WS_cmd)

def callback_SA(message):
    #print('Steering Angle: %.1f' %message.data)
    rospy.loginfo("Steering Angle: %s" %message.data)

def callback_WS(message):
    #print('Wheel Speed: %.1f' %message.data)
    rospy.loginfo("Wheel Speed: %s" %message.data)

def callback_SA_cmd(message):
    #print('Steering Angle Command: %.1f' %message.data)
    rospy.loginfo("Steering Angle Command: %s" %message.data)

def callback_WS_cmd(message):
    #print('Wheel Speed Command: %.1f' %message.data)
    rospy.loginfo("Wheel Speed Command: %s" %message.data)

if __name__ == '__main__':
    rospy.init_node("node_debug")
    subscriber()
    rospy.spin()
