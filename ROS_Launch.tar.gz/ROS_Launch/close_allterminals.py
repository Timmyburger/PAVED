#!/usr/bin/env python
while (xdotool search --class "terminal") == true
    do
        xdotool search --class "terminal" | read id
        xdotool windowactivate "$id"
      #xdotool key ctrl+c
      #xdotool key ctrl+q
        xdotool key ctrl+shift+q
        sleep 0.2
done
