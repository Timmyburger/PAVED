import u6

print('LabJack shutdown initiated.')
d = u6.U6()
d.streamStop()
d.close()
print('Labjack shutdown complete.')
