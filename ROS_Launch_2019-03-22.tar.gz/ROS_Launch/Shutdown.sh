#!/bin/bash

script () {
  source /opt/ros/kinetic/setup.bash
  source ~/ROS/devel/setup.bash
  rosnode kill -a
  sleep 3
  python ~/Desktop/ROS_Launch/u6shutdown.py
  killall roscore
  sleep 2
  Desktop/ROS_Launch/close_terminals.sh
}

export -f script

gnome-terminal -e "bash -c 'script'"
