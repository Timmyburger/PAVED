#!/bin/bash

script () {
  source /opt/ros/kinetic/setup.bash
  source ~/ROS/devel/setup.bash
  roscore &
  sleep 2 && gnome-terminal -e "roslaunch startup startup.launch"
  $SHELL
}

export -f script

gnome-terminal -e "bash -c 'script'"
