#!/usr/bin/env python

import rospy
import serial
import time
import struct
from std_msgs.msg import Float32, Int8, Bool, String, Int32
from numpy import interp

#Set global varialbe to pass to subscriber

SA_Read = 0
SA_Cmd = .5
SA_temp = 0
throttle_cmd = 0
brake_cmd = 0
parking_brake_cmd = 0
trans_cmd = 0
baud = 57600
CPR = 1800*4          #Counts Per Revolution of encoder
NumTurn = 1.1         #Number of steering wheel turns to limit
EncoderMin = -NumTurn*CPR   #Number of turns to limit * CPR
EncoderMax = NumTurn*CPR   #Number of turns to limit * CPR

#Serial communication over USB. To find the current arduino port, type
#"ls -l /dev/ttyACM*" into the terminal
port = '/dev/ttyACM0'
#Establish connection on port at specified baud rate
arduino = serial.Serial(port,baud,timeout=0)

def callback1(msg):
    global SA_Cmd
    SA_Cmd = msg.data
    return SA_Cmd

def callback6(msg):
    global SA_Read
    #Reads in integer from encoder count and converts to float
    SA_Read = float('%i' %msg.data)
    #Reads in float between EncoderMin and EncoderMax and interpolates to float between 0 and 1
    #This represents the "Servo Range Percentage" that will be passed to the arduino
    SA_Read = interp(SA_Read,[EncoderMin,EncoderMax],[0,1])
    return SA_Read

def callback2(msg):
    global throttle_cmd
    # throttle_cmd = str('%.2f' %msg.data)
    throttle_cmd = msg.data

def callback3(msg):
    global brake_cmd
    # brake_cmd = str('%.2f' %msg.data)
    brake_cmd = msg.data

def callback4(msg):
    global parking_brake_cmd
    parking_brake_cmd = str('%.2f' %msg.data)

def callback5(msg):
    global trans_cmd
    trans_cmd = str('%.3f' %msg.data)

def OVERRIDE(msg):
    global OVERRIDE
    OVERRIDE = int(msg.data)

def subscriber():
    sub_OVERRIDE = rospy.Subscriber('topic_OVERRIDE_cmd', Bool, OVERRIDE)
    sub_SA_Cmd = rospy.Subscriber('topic_steer_angle_cmd', Float32, callback1)
    sub_SA = rospy.Subscriber('topic_steer_angle', Int32, callback6)
    sub_Throttle = rospy.Subscriber('topic_throttle_cmd', Float32, callback2)
    sub_Brake = rospy.Subscriber('topic_brake_cmd', Float32, callback3)
    sub_Parking_Brake = rospy.Subscriber('topic_parking_brake_cmd', Bool, callback4)
    sub_Trans = rospy.Subscriber('topic_transmission_cmd', Int8, callback5)


if __name__ == '__main__':
    rospy.init_node("node_translator")
    rate = rospy.Rate(1000) #Hz
    # SA_Cmd_temp = SA_Cmd
    delay = 4
    currenttime = time.time()
    subscriber()
    pub_Debug = rospy.Publisher('topic_DEBUG', String, queue_size=10)
    # pub_temp = rospy.Publisher('topic_DEBUG', Float32, queue_size=10)

    while not rospy.is_shutdown():
        # ArduinoCmd = str('<%.2f,%.2f>' %(SA_Read, SA_Cmd))
        # ArduinoCmd = str('<LED1,500,%.2f>' %SA_Cmd)
        # ArduinoCmd = '<' + SA_Read + ',' + SA_Cmd + '>'
        # arduino.write(ArduinoCmd)
        if not OVERRIDE:
            # temp = str('<%i,%.2f,%.2f,%.2f,%.2f>' %(OVERRIDE, SA_Read, SA_Cmd, throttle_cmd, brake_cmd))
            temp = str('<A%i><B%.2f><C%.2f><D%.2f><E%.2f>' %(OVERRIDE, SA_Read, SA_Cmd, throttle_cmd, brake_cmd))
            # temp = str('<C%.2f>' %SA_Cmd)
            arduino.write(temp)
            pub_Debug.publish(temp)
            # pub_temp.publish(SA_temp)
            arduino.flush()
            #print(SA_Cmd)
            rate.sleep()
        else:
            temp = str('<1,0,0,0,0>')
            arduino.write(temp)
    print('Closing comm port')
    arduino.close()
