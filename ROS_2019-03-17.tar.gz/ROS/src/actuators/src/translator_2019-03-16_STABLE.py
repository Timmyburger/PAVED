#!/usr/bin/env python

import rospy
import serial
import time
import struct
from std_msgs.msg import Float32, Int8, Bool, String, Int32
from numpy import interp

#Set global varialbe to pass to subscriber

SA_read = 0
SA_cmd = 0
SA_temp = 0
throttle_cmd = ''
brake_cmd = ''
parking_brake_cmd = ''
trans_cmd = ''
baud = 57600

#Serial communication over USB. To find the current arduino port, type
#"ls -l /dev/ttyACM*" into the terminal
port = '/dev/ttyACM0'
#Establish connection on port at specified baud rate
arduino = serial.Serial(port,baud,timeout=0)

def callback1(msg):
    global SA_cmd, SA_temp
    #Truncates Steering Angle command to 2 decimal precision
    # SA_temp = float('%.2f' %msg.data)
    # SA_cmd = str('%.2f' %msg.data)
    SA_cmd = msg.data
    # SA_temp = interp(SA_temp,[0,5.1],[0,1])
    # BlinkSpeed = 250 #ms
    # SA_cmd = str('<LED1,%i,%.2f>' %(BlinkSpeed, SA_temp))
    # SA_cmd = str('%.2f' %SA_temp)
    return SA_cmd

def callback6(msg):
    global SA_read
    SA_read = float('%i' %msg.data)
    SA_read = interp(SA_read,[-16000,16000],[0,1])
    # SA_read = float('%.2f' %SA_read)
    # SA_read = str('%.2f' %SA_read)
    return SA_read

def callback2(msg):
    global throttle_cmd
    throttle_cmd = str('%.2f' %msg.data)

def callback3(msg):
    global brake_cmd
    brake_cmd = str('%.3f' %msg.data)

def callback4(msg):
    global parking_brake_cmd
    parking_brake_cmd = str('%.3f' %msg.data)

def callback5(msg):
    global trans_cmd
    trans_cmd = str('%.3f' %msg.data)


def subscriber():
    sub_SA_cmd = rospy.Subscriber('topic_steer_angle_cmd', Float32, callback1)
    sub_SA = rospy.Subscriber('topic_steer_angle', Int32, callback6)
    sub_Throttle = rospy.Subscriber('topic_throttle_cmd', Float32, callback2)
    sub_Brake = rospy.Subscriber('topic_brake_cmd', Float32, callback3)
    sub_Parking_Brake = rospy.Subscriber('topic_parking_brake_cmd', Bool, callback4)
    sub_Trans = rospy.Subscriber('topic_transmission_cmd', Int8, callback5)


if __name__ == '__main__':
    rospy.init_node("node_translator")
    rate = rospy.Rate(1000) #Hz
    # SA_cmd_temp = SA_cmd
    delay = 4
    currenttime = time.time()
    subscriber()
    pub_Debug = rospy.Publisher('topic_DEBUG', String, queue_size=10)
    # pub_temp = rospy.Publisher('topic_DEBUG', Float32, queue_size=10)

    while not rospy.is_shutdown():
        # ArduinoCmd = str('<%.2f,%.2f>' %(SA_read, SA_cmd))
        # ArduinoCmd = str('<LED1,500,%.2f>' %SA_cmd)
        # ArduinoCmd = '<' + SA_read + ',' + SA_cmd + '>'
        # arduino.write(ArduinoCmd)
        temp = str('<%.2f>' %SA_cmd)
        arduino.write(temp)
        pub_Debug.publish(temp)
        # pub_temp.publish(SA_temp)
        arduino.flush()
        #print(SA_cmd)
        rate.sleep()
        # if (time.time() - currenttime) > delay:
        #     time.sleep(1)
        #     arduino.flushOutput
        #     currenttime = time.time()
    print('Closing comm port')
    arduino.close()
