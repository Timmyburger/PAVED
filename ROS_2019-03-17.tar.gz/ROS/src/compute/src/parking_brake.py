#!/usr/bin/env python

import rospy
from std_msgs.msg import Float32, Float64, Int8, Bool

wheel_speed_act = None
pbrake_state = None
OVERRIDE = None
pbrake_cmd = None

def callback1(message):
    global wheel_speed_act
    wheel_speed_act = message.data

def callback2(message):
    global pbrake_state
    pbrake_state = message.data
    if pbrake_state > 0:
        pbrake_state == True
    else:
        pbrake_state == False

def OVERRIDE(message):
    global OVERRIDE
    OVERRIDE = message.data

if __name__ == '__main__':
    rospy.init_node("node_parking_brake")
    sub_WS = rospy.Subscriber('topic_wheel_speed', Float32, callback1)
    sub_OVERRIDE = rospy.Subscriber('topic_OVERRIDE_cmd', Bool, OVERRIDE)
    sub_pbrake = rospy.Subscriber('topic_parking_brake', Int8, callback2)
    pub_pbrake = rospy.Publisher('topic_parking_brake_cmd', Bool, queue_size=10)
    rate = rospy.Rate(1) #Hz

    while not rospy.is_shutdown():
        #======PSEUDO======
        #==OVERRIDE==
        #IF Override detected
        #THEN do nothing
        if not OVERRIDE == True:
        #==Parking Brake Engagement==
        #IF Wheel speed is less than 1 && parking brake is off
        #THEN engage parking brake
        #ELSEIF Wheel speed is less than 1 && parking brake is on
        #THEN disengage parking brake
            if wheel_speed_act < 1 and pbrake_state == False:
                pbrake_cmd = True
            elif wheel_speed_act < 1 and pbrake_state == True:
                pbrake_cmd = False
            pub_pbrake.publish(pbrake_cmd)
        rate.sleep()
