#!/usr/bin/env python

import rospy
from std_msgs.msg import Float32, Float64, Int8, Bool

wheel_speed_act = None
transmission_act = None
OVERRIDE = None

def callback1(message):
    global wheel_speed_act
    wheel_speed_act = message.data

def callback2(message):
    global transmission_act
    transmission_act = message.data

def OVERRIDE(message):
    global OVERRIDE
    OVERRIDE = message.data

if __name__ == '__main__':
    rospy.init_node("node_transmission")
    sub_WS = rospy.Subscriber('topic_wheel_speed', Float32, callback1)
    sub_trans = rospy.Subscriber('topic_transmission', Int8, callback2)
    sub_OVERRIDE = rospy.Subscriber('topic_OVERRIDE_cmd', Bool, OVERRIDE)
    pub_trans = rospy.Publisher('topic_transmission_cmd', Int8, queue_size=10)
    rate = rospy.Rate(100) #Hz

    while not rospy.is_shutdown():
        #======PSEUDO======
        #==OVERRIDE==
        #IF Override detected
        #THEN switch to NEUTRAL
        if not OVERRIDE == True:
        #==Transmission Engagement==
        #IF Wheel speed is zero
        #THEN switch to indicated transmission direction

            transmission_cmd = transmission_act #Placeholder for cmd vs. act logic
            pub_trans.publish(transmission_cmd)
        else:
            transmission_cmd = 2 #Placeholder for cmd vs. act logic
            pub_trans.publish(transmission_cmd)
        rate.sleep()
