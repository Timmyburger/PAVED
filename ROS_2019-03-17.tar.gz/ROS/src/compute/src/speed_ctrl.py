#!/usr/bin/env python

import rospy
from std_msgs.msg import Float32, Float64, Int8, Bool, Int32
from geometry_msgs.msg import Twist

wheel_speed_act = None
steer_angle_act = None
brake_act = None
OVERRIDE = None
lin_x = None
rot_z = None

def callback1(message):
    global wheel_speed_act
    wheel_speed_act = message.data

def callback2(message):
    global steer_angle_act
    steer_angle_act = message.data

def callback3(message):
    global lin_x, rot_z
    lin_x = message.linear.x
    rot_z = message.angular.z
    rospy.loginfo("Set Speed: %.1f" %message.linear.x)
    rospy.loginfo("set Heading: %.1f" %message.angular.z)

def callback4(message):
    global brake_act
    brake_act = message.data

def OVERRIDE(message):
    global OVERRIDE
    OVERRIDE = message.data

if __name__ == '__main__':
    rospy.init_node("node_speed_ctrl")
    sub_OVERRIDE = rospy.Subscriber('topic_OVERRIDE_cmd', Bool, OVERRIDE)
    sub_WS = rospy.Subscriber('topic_wheel_speed', Float32, callback1)
    sub_SA = rospy.Subscriber('topic_steer_angle', Int32, callback2)
    sub_cmd_vel = rospy.Subscriber('cmd_vel', Twist, callback3)
    sub_brake = rospy.Subscriber('topic_brake', Float32, callback4)
    pub_throttle = rospy.Publisher('topic_throttle_cmd', Float32, queue_size=10)
    pub_brake = rospy.Publisher('topic_brake_cmd', Float32, queue_size=10)
    rate = rospy.Rate(2000) #Hz

    while not rospy.is_shutdown():
        #======PSEUDO======
        #==OVERRIDE==
        #IF Override detected
        #THEN set wheel speed command to zero
        if not OVERRIDE:

        #==Max Turning Speed==
        #IF steering angle is above certain threshold
        #THEN cap max speed to X (i.e. Wheel speed - steering angle must be < X)
        #
        #==Command Speed==
        #Compare wheel speed with lin_x command
        #IF Wheel speed - command speed > X (small difference)
        #THEN apply zero throttle
        #ELSEIF Wheel speed - command speed > Y (large difference)
        #THEN apply zero throttle and apply brakes

            throttle_cmd = lin_x #wheel_speed_act #Placeholder for cmd vs. act logic
            brake_cmd = brake_act #Placeholder for cmd vs. act logic
            pub_throttle.publish(throttle_cmd)
            # pub_brake.publish(brake_cmd)
        else:
            throttle_cmd = 0 #Placeholder for cmd vs. act logic
            brake_cmd = 0 #Placeholder for cmd vs. act logic
            pub_throttle.publish(throttle_cmd)
            pub_brake.publish(brake_cmd)
        rate.sleep()
