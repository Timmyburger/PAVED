#!/usr/bin/env python

#Streams in data from LabJack and publishes to the appropriate topics

import u6
import sys
import rospy
from std_msgs.msg import Float32, Time, Int8, Int16, String, Int32, Bool
import random
import time

CPR = 3600
LastTime1 = time.time()
LastTime2 = time.time()
SampleDelay = .1        #How often Wheel Speed mesurements are calculated
MPH = 0
TireDia = 23.2 #Tire diameter = 2*(first number (mm) * second number (ratio)) / 25.4 (mm to in) + third number (in)
SA = 0

def WheelSpeed():
    global LastCount1, LastTime1, MPH
    Count1, = d.getFeedback(u6.Timer0())
    #Calculate RPM and pass back to main function
    Difference = (Count1 - LastCount1)
    if ((time.time() - LastTime1) > SampleDelay):
        RPS = (Difference) / ((time.time()- LastTime1) * CPR)
        #Circumference (in) / 12 (in to ft) * RPS * 60 (sec to min) * 60 (min to hr) / 5280 (ft to mi)
        MPH = (3.14*TireDia/12)*RPS*60*60/5280
        LastCount1 = Count1
        LastTime1 = time.time()
    return MPH

def SteeringAngle():
    global LastCount2, LastTime2
    Count2, = d.getFeedback(u6.Timer2())
    #TEMPORARY 2'S COMPLEMEMNT IMPLEMENTAITON
    #REPLACE WITH CALIBRATION ALGORITHM IN FUTURE VERSIONS
    if Count2 > 2147483647:
        Count2 = Count2 - 4294967294
    SA = Count2
    return SA

def publisher():
    #Read the actual datas
    SA_Read = SteeringAngle()
    WS_Read = WheelSpeed()
    Brake_Read = random.randint(0,100) #Random value as placeholder
    Radar_Read = random.randint(0,100) #Random value as placeholder
    ParkBrake_Read = random.randint(0,1) #Random value as placeholder
    OVERRIDE_Read = False#random.randint(0,1) #Random value as placeholder
    Transmission_Read = random.randint(1,3) #Random value as placeholder

    #Publish the datas
    pub_steer_angle.publish(SA_Read)
    pub_wheel_speed.publish(WS_Read)
    # pub_brake.publish(Brake_Read)
    pub_radar.publish(Radar_Read)
    pub_parking_brake.publish(ParkBrake_Read)
    # pub_OVERRIDE.publish(OVERRIDE_Read)
    pub_transmission.publish(Transmission_Read)


if __name__ == "__main__":
    #Configure LabJack H/W
    d = u6.U6()
    d.getCalibrationData()
    #Configure LabJack stream variables
    #See labjack.com/support/datasheets/u6/low-level-function-reference/streamconfig
    #for definitions of streamConfig variables

    d.configIO(NumberTimersEnabled=4, TimerCounterPinOffset=0)
    d.getFeedback(u6.Timer0Config(8))
    d.getFeedback(u6.Timer1Config(8))
    d.getFeedback(u6.Timer2Config(8))
    d.getFeedback(u6.Timer3Config(8))
    LastCount1, = d.getFeedback(u6.Timer0())
    LastCount2, = d.getFeedback(u6.Timer2())

    #Initiate Publishers
    pub_steer_angle = rospy.Publisher('topic_steer_angle', Int32, queue_size=1)
    pub_wheel_speed = rospy.Publisher('topic_wheel_speed', Float32, queue_size=1)
    pub_brake = rospy.Publisher('topic_brake', Float32, queue_size=1)
    pub_radar = rospy.Publisher('topic_radar', Int8, queue_size=1)
    pub_parking_brake = rospy.Publisher('topic_parking_brake', Int8, queue_size=1)
    pub_OVERRIDE = rospy.Publisher('topic_OVERRIDE', Bool, queue_size=1)
    pub_transmission = rospy.Publisher('topic_transmission', Int8, queue_size=1)

    #Initialize node
    rospy.init_node("node_DAQ")

    #Run publisher
    while not rospy.is_shutdown():
        publisher()

    d.close()
