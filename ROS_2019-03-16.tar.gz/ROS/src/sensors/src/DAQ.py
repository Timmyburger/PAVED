#!/usr/bin/env python

#Streams in data from LabJack and publishes to the appropriate topics

import u6
import sys
import rospy
from std_msgs.msg import Float32, Time, Int8, Int16, String, Int32
import random
import time

CPR = 3600
LastTime1 = time.time()
LastTime2 = time.time()
SampleDelay = .1        #How often Wheel Speed mesurements are calculated
RPM = 0
SA = 0

def WheelSpeed():
    global LastCount1, LastTime1, RPM
    Count1, = d.getFeedback(u6.Timer0())
    # print(Count1)
    Difference = (Count1 - LastCount1)
    if ((time.time() - LastTime1) > SampleDelay):
        RPM = (Difference) / ((time.time()- LastTime1) * CPR)
        LastCount1 = Count1
        LastTime1 = time.time()
    return RPM

def SteeringAngle():
    global LastCount2, LastTime2
    Count2, = d.getFeedback(u6.Timer2())
    #TEMPORARY 2'S COMPLEMEMNT IMPLEMENTAITON
    #REPLACE WITH CALIBRATION ALGORITHM IN FUTURE VERSIONS
    if Count2 > 2147483647:
        Count2 = Count2 - 4294967294
    SA = Count2
    return SA

def publisher():
    #Read the actual datas
    SA_Read = SteeringAngle()
    WS_Read = WheelSpeed()
    Brake_Read = random.randint(0,100) #Random value as placeholder
    Radar_Read = random.randint(0,100) #Random value as placeholder
    ParkBrake_Read = random.randint(0,1) #Random value as placeholder
    OVERRIDE_Read = 0#random.randint(0,1) #Random value as placeholder
    Transmission_Read = random.randint(1,3) #Random value as placeholder

    #Publish the datas
    pub_steer_angle.publish(float(SA_Read))
    pub_wheel_speed.publish(float(WS_Read))
    pub_brake.publish(float(Brake_Read))
    pub_radar.publish(Radar_Read)
    pub_parking_brake.publish(ParkBrake_Read)
    pub_OVERRIDE.publish(OVERRIDE_Read)
    pub_transmission.publish(Transmission_Read)


if __name__ == "__main__":
    #Configure LabJack H/W
    d = u6.U6()
    d.getCalibrationData()
    #Configure LabJack stream variables
    #See labjack.com/support/datasheets/u6/low-level-function-reference/streamconfig
    #for definitions of streamConfig variables

    d.configIO(NumberTimersEnabled=4, TimerCounterPinOffset=0)
    d.getFeedback(u6.Timer0Config(8))
    d.getFeedback(u6.Timer1Config(8))
    d.getFeedback(u6.Timer2Config(8))
    d.getFeedback(u6.Timer3Config(8))
    LastCount1, = d.getFeedback(u6.Timer0())
    LastCount2, = d.getFeedback(u6.Timer2())

    #Initiate Publishers
    pub_steer_angle = rospy.Publisher('topic_steer_angle', Int32, queue_size=1)
    pub_wheel_speed = rospy.Publisher('topic_wheel_speed', Float32, queue_size=1)
    pub_brake = rospy.Publisher('topic_brake', Float32, queue_size=1)
    pub_radar = rospy.Publisher('topic_radar', Int8, queue_size=1)
    pub_parking_brake = rospy.Publisher('topic_parking_brake', Int8, queue_size=1)
    pub_OVERRIDE = rospy.Publisher('topic_OVERRIDE', Int8, queue_size=1)
    pub_transmission = rospy.Publisher('topic_transmission', Int8, queue_size=1)

    #Initialize node
    rospy.init_node("node_DAQ")

    #Run publisher
    while not rospy.is_shutdown():
        publisher()

    d.close()
