#!/usr/bin/env python

#Streams in data from LabJack and publishes to the appropriate topics

import u6
import sys
import rospy
from std_msgs.msg import Float32, Time, Int8
import random

def publisher():
    pub_steer_angle = rospy.Publisher('topic_steer_angle', Float32, queue_size=1)
    pub_wheel_speed = rospy.Publisher('topic_wheel_speed', Float32, queue_size=1)
    pub_brake = rospy.Publisher('topic_brake', Float32, queue_size=1)
    pub_radar = rospy.Publisher('topic_radar', Int8, queue_size=1)
    pub_parking_brake = rospy.Publisher('topic_parking_brake', Int8, queue_size=1)
    pub_OVERRIDE = rospy.Publisher('topic_OVERRIDE', Int8, queue_size=1)
    pub_transmission = rospy.Publisher('topic_transmission', Int8, queue_size=1)

    #Read in data from LabJack here and publish to appropriate topics
    for i in d.streamData():
        #Read the actual datas
        SA_Read = sum(i["AIN0"])/len(i["AIN0"])
        WS_Read = random.randint(0,100) #Random value as placeholder
        Brake_Read = random.randint(0,100) #Random value as placeholder
        Radar_Read = random.randint(0,100) #Random value as placeholder
        ParkBrake_Read = random.randint(0,1) #Random value as placeholder
        OVERRIDE_Read = random.randint(0,1) #Random value as placeholder
        Transmission_Read = random.randint(1,3) #Random value as placeholder

        #Publish the datas
        pub_steer_angle.publish(float(SA_Read))
        pub_wheel_speed.publish(float(WS_Read))
        pub_brake.publish(float(Brake_Read))
        pub_radar.publish(Radar_Read)
        pub_parking_brake.publish(ParkBrake_Read)
        pub_OVERRIDE.publish(OVERRIDE_Read)
        pub_transmission.publish(Transmission_Read)


if __name__ == "__main__":
    #Configure LabJack H/W
    d = u6.U6()
    d.getCalibrationData()
    #Configure LabJack stream variables
    #See labjack.com/support/datasheets/u6/low-level-function-reference/streamconfig
    #for definitions of streamConfig variables

    #Publishing rate corresponds to ScanFreq/5
    ScanFreq = 10000 #Hz
    SampleNum = 10
    d.streamConfig(NumChannels=2, ChannelNumbers=[0, 1], ChannelOptions=[0, 0],\
        SettlingFactor=1, ResolutionIndex=0, ScanFrequency=ScanFreq,\
        SamplesPerPacket=SampleNum)

    #Initialize node
    rospy.init_node("node_DAQ")
    #Start stream
    d.streamStart()

    #Run publisher
    while not rospy.is_shutdown():
        publisher()

    d.streamStop()
    d.close()
