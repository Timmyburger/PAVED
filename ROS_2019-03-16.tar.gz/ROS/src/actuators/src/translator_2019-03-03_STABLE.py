#!/usr/bin/env python

import rospy
import serial
import time
import struct
from std_msgs.msg import Float32, Int8, Bool, String
from numpy import interp

#Set global varialbe to pass to subscriber

SA_cmd = ''
SA_temp = 0
throttle_cmd = ''
brake_cmd = ''
parking_brake_cmd = ''
trans_cmd = ''
baud = 57600

#Serial communication over USB. To find the current arduino port, type
#"ls -l /dev/ttyACM*" into the terminal
port = '/dev/ttyACM0'
#Establish connection on port at specified baud rate
arduino = serial.Serial(port,baud,timeout=0)

def callback1(msg):
    global SA_cmd, SA_temp
    # Takes value and remaps to percentage of servo range 0% to 100%
    SA_temp = float('%.2f' %msg.data)
    SA_temp = interp(SA_temp,[0,5.1],[0,1])
    #SA_temp = msg.data/5
    BlinkSpeed = 250 #ms
    SA_cmd = str('<LED1,%i,%.2f>' %(BlinkSpeed, SA_temp))

def callback2(msg):
    global throttle_cmd
    throttle_cmd = str('%.3f' %msg.data)

def callback3(msg):
    global brake_cmd
    brake_cmd = str('%.3f' %msg.data)

def callback4(msg):
    global parking_brake_cmd
    parking_brake_cmd = str('%.3f' %msg.data)

def callback5(msg):
    global trans_cmd
    trans_cmd = str('%.3f' %msg.data)

def subscriber():
    sub_SA = rospy.Subscriber('topic_steer_angle_cmd', Float32, callback1)
    sub_Throttle = rospy.Subscriber('topic_throttle_cmd', Float32, callback2)
    sub_Brake = rospy.Subscriber('topic_brake_cmd', Float32, callback3)
    sub_Parking_Brake = rospy.Subscriber('topic_parking_brake_cmd', Bool, callback4)
    sub_Trans = rospy.Subscriber('topic_transmission_cmd', Int8, callback5)


if __name__ == '__main__':
    rospy.init_node("node_translator")
    rate = rospy.Rate(1000) #Hz
    # SA_cmd_temp = SA_cmd
    delay = 4
    currenttime = time.time()
    subscriber()
    pub = rospy.Publisher('topic_DEBUG', String, queue_size=10)
    # pub_temp = rospy.Publisher('topic_DEBUG', Float32, queue_size=10)

    while not rospy.is_shutdown():
        arduino.write(SA_cmd)
        pub.publish(SA_cmd)
        # pub_temp.publish(SA_temp)
        arduino.flush()
        #print(SA_cmd)
        rate.sleep()
        # if (time.time() - currenttime) > delay:
        #     time.sleep(1)
        #     arduino.flushOutput
        #     currenttime = time.time()
    print('Closing comm port')
    arduino.close()
