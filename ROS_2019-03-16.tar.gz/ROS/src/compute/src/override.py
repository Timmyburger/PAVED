#!/usr/bin/env python

import rospy
from std_msgs.msg import Int8, Bool

OVERRIDE_act = None

def OVERRIDE(message):
    global OVERRIDE_act
    OVERRIDE_act = message.data

if __name__ == '__main__':
    rospy.init_node("node_OVERRIDE")
    sub_OVERRIDE = rospy.Subscriber('topic_OVERRIDE', Int8, OVERRIDE)
    pub_OVERRIDE = rospy.Publisher('topic_OVERRIDE_cmd', Bool, queue_size=10)
    rate = rospy.Rate(2000) #Hz

    while not rospy.is_shutdown():
        #======PSEUDO======
        #==OVERRIDE==
        #Compare voltage on override input
        #IF above threshold
        #THEN publish true
        #ELSE publish false
        #==Max Turning Speed==
        #IF Wheel speed is above certain threshold
        #THEN discard steering command (i.e. Wheel speed - steering angle must be < X)

        #Placeholder for cmd vs. act logic
        if OVERRIDE_act > 0:
            OVERRIDE_cmd = True
        else:
            OVERRIDE_cmd = False
        pub_OVERRIDE.publish(OVERRIDE_cmd)
        rate.sleep()
