#!/usr/bin/env python

import rospy
from std_msgs.msg import Float32, Float64, Int8, Bool, Int32
from geometry_msgs.msg import Twist

steer_angle_act = None
wheel_speed_act = None
OVERRIDE = None
rot_z = None

def callback1(message):
    global wheel_speed_act
    wheel_speed_act = message.data

def callback2(message):
    global steer_angle_act
    steer_angle_act = message.data

def callback3(message):
    global lin_x, rot_z
    lin_x = message.linear.x
    rot_z = message.angular.z
    rospy.loginfo("Set Speed: %.1f" %message.linear.x)
    rospy.loginfo("set Heading: %.1f" %message.angular.z)

def OVERRIDE(message):
    global OVERRIDE
    OVERRIDE = message.data

if __name__ == '__main__':
    rospy.init_node("node_angle_ctrl")
    sub_OVERRIDE = rospy.Subscriber('topic_OVERRIDE_cmd', Bool, OVERRIDE)
    sub_WS = rospy.Subscriber('topic_wheel_speed', Float32, callback1)
    sub_SA = rospy.Subscriber('topic_steer_angle', Int32, callback2)
    pub_SA = rospy.Publisher('topic_steer_angle_cmd', Float32, queue_size=10)
    sub_cmd_vel = rospy.Subscriber('cmd_vel', Twist, callback3)
    rate = rospy.Rate(2000) #Hz

    while not rospy.is_shutdown():
        #======PSEUDO======
        #==OVERRIDE==
        #IF Override detected
        #THEN switch discard all steering commands
        if not OVERRIDE == True:
        #
        #==Max Turning Speed==
        #IF Wheel speed is above certain threshold
        #THEN discard steering command (i.e. Wheel speed - steering angle must be < X)

            steer_angle_cmd = rot_z #steer_angle_act #Placeholder for cmd vs. act logic
            pub_SA.publish(steer_angle_cmd)
        rate.sleep()
