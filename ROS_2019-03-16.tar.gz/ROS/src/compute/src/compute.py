#!/usr/bin/env python

import rospy
from std_msgs.msg import Float32, Float64
from geometry_msgs.msg import Twist

wheel_speed_act = None
steer_angle_act = None

def callback1(message):
    global wheel_speed_act
    wheel_speed_act = message.data

def callback2(message):
    global steer_angle_act
    steer_angle_act = message.data

def callback3(message):
    global lin_x, rot_z
    lin_x = message.linear.x
    rot_z = message.angular.z
    rospy.loginfo("Set Speed: %.1f" %message.linear.x)
    rospy.loginfo("set Heading: %.1f" %message.angular.z)

if __name__ == '__main__':
    rospy.init_node("node_compute")
    sub_WS = rospy.Subscriber('topic_wheel_speed', Float32, callback1)
    sub_SA = rospy.Subscriber('topic_steer_angle', Float32, callback2)
    sub_cmd_vel = rospy.Subscriber('cmd_vel', Twist, callback3)
    pub_WS = rospy.Publisher('topic_wheel_speed_cmd', Float32, queue_size=10)
    pub_SA = rospy.Publisher('topic_steer_angle_cmd', Float32, queue_size=10)
    rate = rospy.Rate(2000) #Hz

    while not rospy.is_shutdown():
        pub_WS.publish(wheel_speed_act)
        pub_SA.publish(steer_angle_act)
        rate.sleep()
